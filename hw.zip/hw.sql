
1. Из таблиц locations и countries выбрать адреса (location_id, street_address, city, state_province, country_name) всех подразделений

select locations.LOCATION_ID, locations.STREET_ADDRESS,locations.CITY,
locations.STATE_PROVINCE,countries.COUNTRY_NAME FROM departments
JOIN locations on  departments.LOCATION_ID=locations.LOCATION_ID
JOIN countries on countries.COUNTRY_ID=locations.COUNTRY_ID

create view one as
select locations.LOCATION_ID, locations.STREET_ADDRESS,locations.CITY,
locations.STATE_PROVINCE,countries.COUNTRY_NAME FROM departments
JOIN locations on  departments.LOCATION_ID=locations.LOCATION_ID
JOIN countries on countries.COUNTRY_ID=locations.COUNTRY_ID



2. Из таблиц employees и departments выбрать имена сотрудников (first_name, last name) и названия подразделений (department_name) в которых они работают.

SELECT employees.FIRST_NAME, employees.LAST_NAME,departments.DEPARTMENT_NAME
FROM job_history
JOIN employees on employees.EMPLOYEE_ID=job_history.EMPLOYEE_ID
JOIN departments on departments.DEPARTMENT_ID=job_history.DEPARTMENT_ID

create view two as 
SELECT employees.FIRST_NAME, employees.LAST_NAME,departments.DEPARTMENT_NAME
FROM job_history
JOIN employees on employees.EMPLOYEE_ID=job_history.EMPLOYEE_ID
JOIN departments on departments.DEPARTMENT_ID=job_history.DEPARTMENT_ID

3. Из таблиц locations, employees и departments выбрать имена (first_name, last_name), должность (job_id), номер подразделения (department_id), 
   и названия подразделения для сотрудников из города London

SELECT employees.FIRST_NAME,employees.LAST_NAME,employees.JOB_ID,employees.DEPARTMENT_ID,
departments.DEPARTMENT_NAME 
FROM employees 
JOIN departments on employees.DEPARTMENT_ID=departments.DEPARTMENT_ID
JOIN locations on departments.LOCATION_ID=locations.LOCATION_ID 
WHERE locations.CITY='London'

create view three as 
SELECT employees.FIRST_NAME,employees.LAST_NAME,employees.JOB_ID,employees.DEPARTMENT_ID,
departments.DEPARTMENT_NAME 
FROM employees 
JOIN departments on employees.DEPARTMENT_ID=departments.DEPARTMENT_ID
JOIN locations on departments.LOCATION_ID=locations.LOCATION_ID 
WHERE locations.CITY='London'

4. Из таблиц employees, departments и locations выбрать названия подразделений (department_name), имя сотрудника (first_name), и город (city)

SELECT departments.DEPARTMENT_NAME,employees.FIRST_NAME,locations.CITY
FROM employees
JOIN departments on employees.DEPARTMENT_ID=departments.DEPARTMENT_ID
JOIN locations on locations.LOCATION_ID=departments.LOCATION_ID

create view four as 
SELECT departments.DEPARTMENT_NAME,employees.FIRST_NAME,locations.CITY
FROM employees
JOIN departments on employees.DEPARTMENT_ID=departments.DEPARTMENT_ID
JOIN locations on locations.LOCATION_ID=departments.LOCATION_ID

Для каждого запроса сделать представление


